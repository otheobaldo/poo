public class Aluno{

    private int matricula;
    private float prova1, prova2, trabalho;
    private String nome;
    
    public Aluno(String nome, int matricula, float prova1, float prova2, float trabalho){
        this.nome = nome;
        this.matricula = matricula;
        this.prova1 = prova1;
        this.prova2 = prova2;
        this.trabalho = trabalho;
    }

    public float calcularMedia(){
        float media = (this.prova1*4 + this.prova2*4 + this.trabalho*2)/10;
        return (media);
    }

    public String retornarSituacao(){
        if (this.calcularMedia() > 6)
            return ("Aprovado");
        else
            return ("Reprovado");
    }
}
