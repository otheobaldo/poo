#include <iostream>

class Quadrado
{
    public:
        Quadrado(double lado);
        double criarPerimetro();
        double criarArea();
        void imprimir();

    private:
        double lado;
};