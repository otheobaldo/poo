#include <iostream>
#include "quadrado.h"
using namespace std;

Quadrado::Quadrado(double lado):
    lado{lado}
{
}

double Quadrado::criarArea()
{
    double area = 0;
    area = lado * lado;
    return area;
}

double Quadrado::criarPerimetro()
{
    double perimetro = 0;
    perimetro = lado*4;
    return perimetro;
}

void Quadrado::imprimir()
{
    cout << "Lado: " << lado << ", Área: " << this->criarArea() << ", Perímetro: " << this->criarPerimetro() << ".\n";
}