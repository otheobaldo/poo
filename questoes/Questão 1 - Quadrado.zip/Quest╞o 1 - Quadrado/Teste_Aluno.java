public class Teste_Aluno {
    public static void main (String[] a){
        Aluno aluno1 = new Aluno("Rodrigo", 1515, 10, 6, 3);
        System.out.print(aluno1.calcularMedia());
    }
}