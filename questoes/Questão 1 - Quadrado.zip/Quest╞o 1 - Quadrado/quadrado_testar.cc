#include <iostream>
#include "quadrado.h"
using namespace std;

int main(int argc, char *argv[])
{
    Quadrado q1{4};    
    cout << "Perímetro: " << q1.criarPerimetro() << endl;
    cout << "Área: " << q1.criarArea() << endl;
    q1.imprimir();
    return 0;
}